#!/usr/bin/python
"""Upload videos to Youtube."""
from distutils.core import setup

setup_kwargs = {
    "name": "youtube-change-desc",
    "version": "0.1.0",
    "description": "Change videos description into Youtube",
    "author": "tsycorne",
    "author_email": "",
    "url": "",
    "packages": ["youtube_change_desc/", "youtube_change_desc/auth"],
    "scripts": ["bin/youtube-change-desc"],
    "license": "",
    "long_description": " ".join(__doc__.strip().splitlines()),
    "classifiers": [
        'Development Status :: 1 - Beta',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved ::',
        'Natural Language :: English',
        'Operating System :: POSIX',
        'Operating System :: Microsoft :: Windows',
        'Programming Language :: Python',
        'Topic :: Internet :: WWW/HTTP',
    ],
    "entry_points": {
        'console_scripts': [
			'youtube-change-desc = youtube_change_desc.main:run'
        ],
    },
    "install_requires":[
        'google-api-python-client',
        'progressbar2'
    ]
}

setup(**setup_kwargs)
